import customtkinter as ctk
import tkinter as tk
from datetime import datetime
import os
from pathlib import Path

# Function to perform calculations and update the result
def calculate_training_time():
    try:
        # Retrieve values from entry fields
        dataset_size = int(dataset_size_entry.get())
        batch_size = int(batch_size_entry.get())
        epochs = int(epochs_entry.get())
        epoch_per_second = float(epoch_per_second_entry.get())

        # Perform calculations
        steps_per_epoch = dataset_size / batch_size
        training_cycles = epochs / steps_per_epoch

        cycle_time_seconds = epoch_per_second * epochs
        cycle_time_hours = int(cycle_time_seconds // 3600)
        cycle_time_minutes = int((cycle_time_seconds % 3600) // 60)
        cycle_time_seconds = int(cycle_time_seconds % 60)

        # Display results
        results_text = (
            f"Steps per epoch: {steps_per_epoch:.2f}\n"
            f"Number of training cycles: {training_cycles:.2f}\n"
            f"Cycle time: {cycle_time_hours} hours, "
            f"{cycle_time_minutes} minutes, {cycle_time_seconds} seconds"
        )
        result_label.configure(text=results_text)

        # Enable save button
        save_button.configure(state=tk.NORMAL)
    except ValueError:
        result_label.configure(text="Please enter valid numbers in all fields.")

# Function to save the results to a log file
def save_log_file():
    model_name = model_name_entry.get()
    if not model_name:
        result_label.configure(text="Please enter a model name.")
        return

    # Define the directory path for saving the log
    script_dir = Path(__file__).resolve().parent
    voiceclone_x_path = script_dir.parent.parent / "Voiceclone X (App)"

    if not voiceclone_x_path.is_dir():
        result_label.configure(text="The 'Voiceclone X (App)' directory was not found.")
        return

    history_dir = voiceclone_x_path / "calculation history"
    history_dir.mkdir(parents=True, exist_ok=True)  # Create directory if it doesn't exist

    # Prepare the file name and content
    file_name = f"{model_name}_calculation.txt"
    file_path = history_dir / file_name
    results_text = result_label.cget("text")

    # Prepare the log file content with model name at the top and no extra spaces
    content = f"Model name: {model_name}\n{results_text}"

    # Save content to the file
    try:
        with file_path.open("w") as file:
            file.write(content)
        result_label.configure(text=f"Log saved as {file_name} in {history_dir}")
    except Exception as e:
        result_label.configure(text=f"Error saving file: {e}")

# Create main application window
app = ctk.CTk()
app.title("Voice Model Training Calculator")
app.geometry("350x680")  # Set window size

# Define a modern color scheme
dark_gray = "#121212"  # Dark gray color
header_bg_color = "#1E1E1E"
header_text_color = "#FFFFFF"
input_frame_bg_color = "#2E2E2E"
button_bg_color = "#FF6F61"
button_text_color = "#FFFFFF"

# Set main window background color
app.configure(bg=dark_gray)

# Create a frame for the header
header_frame = ctk.CTkFrame(app, bg_color=header_bg_color, corner_radius=10)
header_frame.pack(pady=10, fill=tk.X)

# Create and place header label in the header frame
header_label = ctk.CTkLabel(
    header_frame, 
    text="Train Calculator", 
    font=("Arial", 18, "bold"),
    text_color=header_text_color
)
header_label.pack()

# Create a frame to hold the result label and center it
result_frame = ctk.CTkFrame(app, bg_color=dark_gray)
result_frame.pack(pady=10, fill=tk.X)

# Create and place result label in the frame
result_label = ctk.CTkLabel(result_frame, text="", anchor="center", justify="left", height=100, font=("Arial", 12), text_color="#FFFFFF")
result_label.pack(pady=10, padx=10, fill=tk.BOTH)

# Create a frame for input fields and button
input_frame = ctk.CTkFrame(app, bg_color=input_frame_bg_color, corner_radius=10)
input_frame.pack(pady=10, fill=tk.BOTH, expand=True)

# Create and place model name label and entry field
model_name_label = ctk.CTkLabel(input_frame, text="Model Name:", text_color="#FFFFFF", bg_color=input_frame_bg_color)
model_name_label.grid(row=0, column=0, pady=10, padx=10, sticky="w")
model_name_entry = ctk.CTkEntry(input_frame, corner_radius=10)
model_name_entry.grid(row=0, column=1, pady=10, padx=10)

# Create and place input labels and entry fields
dataset_size_label = ctk.CTkLabel(input_frame, text="Dataset Size:", text_color="#FFFFFF", bg_color=input_frame_bg_color)
dataset_size_label.grid(row=1, column=0, pady=10, padx=10, sticky="w")
dataset_size_entry = ctk.CTkEntry(input_frame, corner_radius=10)
dataset_size_entry.grid(row=1, column=1, pady=10, padx=10)

batch_size_label = ctk.CTkLabel(input_frame, text="Batch Size:", text_color="#FFFFFF", bg_color=input_frame_bg_color)
batch_size_label.grid(row=2, column=0, pady=10, padx=10, sticky="w")
batch_size_entry = ctk.CTkEntry(input_frame, corner_radius=10)
batch_size_entry.grid(row=2, column=1, pady=10, padx=10)

epochs_label = ctk.CTkLabel(input_frame, text="Number of Epochs:", text_color="#FFFFFF", bg_color=input_frame_bg_color)
epochs_label.grid(row=3, column=0, pady=10, padx=10, sticky="w")
epochs_entry = ctk.CTkEntry(input_frame, corner_radius=10)
epochs_entry.grid(row=3, column=1, pady=10, padx=10)

epoch_per_second_label = ctk.CTkLabel(input_frame, text="Epoch per Second:", text_color="#FFFFFF", bg_color=input_frame_bg_color)
epoch_per_second_label.grid(row=4, column=0, pady=10, padx=10, sticky="w")
epoch_per_second_entry = ctk.CTkEntry(input_frame, corner_radius=10)
epoch_per_second_entry.grid(row=4, column=1, pady=10, padx=10)

# Create and place Calculate button with drum pad design
calculate_button = ctk.CTkButton(
    input_frame, 
    text="Calculate", 
    command=calculate_training_time,
    width=150,  # Increase button width
    height=80,  # Increase button height
    corner_radius=20,  # Make corners rounded
    fg_color=button_bg_color,  # Bright color for modern look
    text_color=button_text_color,  # White text color
    font=("Arial", 16, "bold")  # Larger, bold font
)
# Place button in the middle of the input fields
calculate_button.grid(row=5, column=1, padx=20, pady=20, sticky="e")

# Create and place Save button
save_button = ctk.CTkButton(
    input_frame, 
    text="Save Log", 
    command=save_log_file,
    width=150,  # Button width
    height=60,  # Button height
    corner_radius=10,  # Make corners rounded
    fg_color=button_bg_color,  # Bright color for modern look
    text_color=button_text_color,  # White text color
    font=("Arial", 14, "bold")  # Larger, bold font
)
# Place button below the calculate button
save_button.grid(row=6, column=1, padx=20, pady=20, sticky="e")
save_button.configure(state=tk.DISABLED)  # Initially disable save button

# Create and place directory label
directory_label = ctk.CTkLabel(app, text="", text_color="#FFFFFF", bg_color=dark_gray)
directory_label.pack(pady=10)

# Start the application
app.mainloop()
