#4. Install Project Dependency 

#Ask the user if they want to download and continue
user_input = input("Install Project Dependency? (Y/N): ").strip().lower()

if user_input != 'y':
    print("Operation cancelled.")
else:
    import os
    import requests
    from zipfile import ZipFile
    from tqdm import tqdm
    import shutil

    # URL and local paths
    zip_url = "https://huggingface.co/datasets/lilbotai/RVC_Installer/resolve/main/RVC.zip?download=true"
    zip_file_path = r"C:\RVC\RVC.zip"
    extracted_folder_path = r"C:\RVC"

    # Create the directory if it doesn't exist
    os.makedirs(extracted_folder_path, exist_ok=True)

    # Download the zip file with a loading circle
    response = requests.get(zip_url, stream=True)
    response.raise_for_status()
    total_size = int(response.headers.get('content-length', 0))
    block_size = 1024
    with open(zip_file_path, "wb") as zip_file, tqdm(
            desc="Downloading",
            total=total_size,
            unit='B',
            unit_scale=True,
            unit_divisor=1024,
    ) as progress_bar:
        for data in response.iter_content(block_size):
            progress_bar.update(len(data))
            zip_file.write(data)

    # Extract the contents
    with ZipFile(zip_file_path, 'r') as zip_ref:
        zip_ref.extractall(extracted_folder_path)

    # Move the 'content' folder to the main 'Voice Training' folder
    content_folder_path = os.path.join(extracted_folder_path, 'RVC', 'content')
    shutil.move(content_folder_path, extracted_folder_path)

    # Delete the empty 'RVC' folder
    rvc_folder_path = os.path.join(extracted_folder_path, 'RVC')
    os.rmdir(rvc_folder_path)

    # Delete the zip file
    os.remove(zip_file_path)

    print("Installation complete")