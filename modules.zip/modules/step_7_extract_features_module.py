#7. Extract Features

import os

# Ask the user if they want to extract features and continue
user_input = input("Extract Features? (Y/N): ").strip().lower()

if user_input == 'y':
    # Define the main path
    main_path = r'C:\RVC\content\project-main'

    # Get the list of logs (subdirectories) in the logs folder
    logs_folder = os.path.join(main_path, 'logs')
    models = [d for d in os.listdir(logs_folder) if os.path.isdir(os.path.join(logs_folder, d))]

    if not models:
        print("No models found in the logs folder.")
    else:
        # Display dropdown menu for log folder selection
        print("Select a model folder from the list below:")
        for i, model in enumerate(models, start=1):
            print(f"{i}. {model}")

        model_choice = int(input("Enter the number corresponding to your model: "))
        model_name = models[model_choice - 1]  # Get the selected model name

        # Define the dataset folder path based on the model_name input
        dataset_path = os.path.join(r'C:\RVC\content\dataset', model_name)

        # Present options for f0method
        f0methods = ['pm', 'harvest', 'rmvpe', 'rmvpe_gpu']
        print("Choose f0method:")
        for i, method in enumerate(f0methods, 1):
            print(f"{i}. {method}")

        # Input function for f0method
        choice = input("Enter the number corresponding to your choice: ").strip()

        try:
            choice = int(choice)
            if 1 <= choice <= len(f0methods):
                f0method = f0methods[choice - 1]
            else:
                raise ValueError("Invalid choice.")
        except ValueError as e:
            print(f"Error: {e}")
            print("Invalid input. Please restart the script and choose a valid number.")
            exit()

        # Change directory to the main path
        os.chdir(main_path)

        # Create log directory if not exists
        log_dir = os.path.join(main_path, 'logs', model_name)
        os.makedirs(log_dir, exist_ok=True)

        # Open log file
        with open(os.path.join(log_dir, 'extract_f0_feature.log'), 'w') as f:
            print("Starting...")

        # Run the appropriate command based on f0method
        if f0method != "rmvpe_gpu":
            os.system(r'python infer\modules\train\extract\extract_f0_print.py {} 2 {}'.format(log_dir, f0method))
        else:
            os.system(r'python infer\modules\train\extract\extract_f0_rmvpe.py 1 0 0 {} True'.format(log_dir))

        # Extract feature
        os.system(r'python infer\modules\train\extract_feature_print.py cuda:0 1 0 0 {} v2'.format(log_dir))

        # Check if extraction is successful
        with open(os.path.join(log_dir, 'extract_f0_feature.log'), 'r') as f:
            if 'all-feature-done' in f.read():
                print("\u2714 Success")
            else:
                print("Error preprocessing data... Make sure your data was preprocessed.")
else:
    print("Operation cancelled.")