#5. Create a Dataset

import os
import shutil
import wave
import math

def get_user_input(prompt, default_value=None, input_type=str):
    user_input = input(f"{prompt} [{default_value}]: ").strip()
    return input_type(user_input) if user_input else default_value

def segment_wav(input_file, output_folder, segment_duration=10):
    with wave.open(input_file, 'rb') as input_wav:
        sample_width = input_wav.getsampwidth()
        framerate = input_wav.getframerate()
        num_frames = input_wav.getnframes()
        total_duration = num_frames / framerate
        frames_per_segment = int(framerate * segment_duration)
        input_file_name = os.path.splitext(os.path.basename(input_file))[0]

        os.makedirs(output_folder, exist_ok=True)

        for segment_index in range(math.ceil(total_duration / segment_duration)):
            start_frame = segment_index * frames_per_segment
            end_frame = min((segment_index + 1) * frames_per_segment, num_frames)

            input_wav.setpos(start_frame)
            frames = input_wav.readframes(end_frame - start_frame)

            output_file = os.path.join(output_folder, f"{input_file_name}_segment{segment_index + 1}.wav")
            with wave.open(output_file, 'wb') as output_wav:
                output_wav.setnchannels(input_wav.getnchannels())
                output_wav.setsampwidth(sample_width)
                output_wav.setframerate(framerate)
                output_wav.writeframes(frames)

            print(f"Segment {segment_index + 1} created: {output_file}")

def main():
    user_input = input("Dataset? (Y/N): ").strip().lower()
    
    if user_input != 'y':
        print("Operation cancelled.")
        return

    input_file_path = input("Enter the path to the audio WAV file: ").strip('"')
    output_folder_path = rf"C:\RVC\content\dataset\{os.path.splitext(os.path.basename(input_file_path))[0]}"
    segment_duration_seconds = get_user_input("Enter the segment duration in seconds (10 seconds is the limit)", 10, float)

    segment_wav(input_file_path, output_folder_path, segment_duration_seconds)
    
    # Copy the voice audio to the specified path
    saved_audios_path = r"C:\RVC\content\saved_audios"
    os.makedirs(saved_audios_path, exist_ok=True)
    shutil.copy2(input_file_path, saved_audios_path)
    print(f"Saved {input_file_path} to {saved_audios_path}")

if __name__ == "__main__":
    main()