#8. Train Index

import os
import numpy as np
import faiss
from sklearn.cluster import MiniBatchKMeans
import traceback

# Ask the user if they want to train their index and continue
user_input = input("Train Index? (Y/N): ").strip().lower()

if user_input != 'y':
    print("Operation cancelled.")
else:
    def train_index(model_name):
        main_path = r"C:\RVC\content\project-main"
        exp_dir = os.path.join(main_path, "logs", model_name)
        os.makedirs(exp_dir, exist_ok=True)

        feature_dir = os.path.join(exp_dir, "3_feature256" if version19 == "v1" else "3_feature768")

        if not os.path.exists(feature_dir):
            return "Please perform feature extraction first!"

        listdir_res = list(os.listdir(feature_dir))

        if len(listdir_res) == 0:
            return "Please perform feature extraction first！"

        infos = []
        npys = []

        for name in sorted(listdir_res):
            phone = np.load(os.path.join(feature_dir, name))
            npys.append(phone)

        big_npy = np.concatenate(npys, 0)
        big_npy_idx = np.arange(big_npy.shape[0])
        np.random.shuffle(big_npy_idx)
        big_npy = big_npy[big_npy_idx]

        if big_npy.shape[0] > 2e5:
            infos.append("Trying doing kmeans %s shape to 10k centers." % big_npy.shape[0])
            yield "\n".join(infos)
            try:
                big_npy = (
                    MiniBatchKMeans(
                        n_clusters=10000,
                        verbose=True,
                        batch_size=256 * os.cpu_count(),
                        compute_labels=False,
                        init="random",
                    )
                    .fit(big_npy)
                    .cluster_centers_
                )
            except:
                info = traceback.format_exc()
                infos.append(info)
                yield "\n".join(infos)

        np.save(os.path.join(exp_dir, "total_fea.npy"), big_npy)
        n_ivf = min(int(16 * np.sqrt(big_npy.shape[0])), big_npy.shape[0] // 39)
        infos.append("%s,%s" % (big_npy.shape, n_ivf))
        yield "\n".join(infos)
        index = faiss.index_factory(256 if version19 == "v1" else 768, "IVF%s,Flat" % n_ivf)
        infos.append("training")
        yield "\n".join(infos)
        index_ivf = faiss.extract_index_ivf(index)
        index_ivf.nprobe = 1
        index.train(big_npy)
        faiss.write_index(
            index,
            os.path.join(
                exp_dir,
                "trained_IVF%s_Flat_nprobe_%s_%s_%s.index" % (n_ivf, index_ivf.nprobe, model_name, version19),
            ),
        )

        infos.append("adding")
        yield "\n".join(infos)
        batch_size_add = 8192

        for i in range(0, big_npy.shape[0], batch_size_add):
            index.add(big_npy[i : i + batch_size_add])

        faiss.write_index(
            index,
            os.path.join(
                exp_dir,
                "added_IVF%s_Flat_nprobe_%s_%s_%s.index" % (n_ivf, index_ivf.nprobe, model_name, version19),
            ),
        )

        infos.append(
            "Index built successfully，added_IVF%s_Flat_nprobe_%s_%s_%s.index" % (n_ivf, index_ivf.nprobe, model_name, version19)
        )

    # Define the main path
    main_path = r'C:\RVC\content\project-main'

    # Get the list of logs (subdirectories) in the logs folder
    logs_folder = os.path.join(main_path, 'logs')
    models = [d for d in os.listdir(logs_folder) if os.path.isdir(os.path.join(logs_folder, d))]

    if not models:
        print("No models found in the logs folder.")
    else:
        # Display dropdown menu for log folder selection
        print("Select a model folder from the list below:")
        for i, model in enumerate(models, start=1):
            print(f"{i}. {model}")

        model_choice = int(input("Enter the number corresponding to your model: "))
        model_name = models[model_choice - 1]  # Get the selected model name

        version19 = 'v2'  # Assuming this value is fixed
        training_log = train_index(model_name)

        for line in training_log:
            print(line)
            if 'adding' in line:
                print("\u2714 Success")