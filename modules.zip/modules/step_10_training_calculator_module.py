#10. Training Calculator 

user_input = input("Calculator? (Y/N): ").strip().lower()

if user_input != 'y':
    print("Operation cancelled.")
else:
    import time

    # Input functions
    dataset_size = int(input("Enter the dataset size: "))
    batch_size = int(input("Specify batch size: "))
    epochs = int(input("Input number of epochs: "))
    epoch_per_second = float(input("Input epoch per second:"))

    # Calculate steps per epoch
    steps_per_epoch = dataset_size / batch_size

    # Calculate number of training cycles
    training_cycles = epochs / steps_per_epoch

    # Calculate cycle time
    cycle_time_seconds = epoch_per_second * epochs
    cycle_time_hours = int(cycle_time_seconds // 3600)
    cycle_time_minutes = int((cycle_time_seconds % 3600) // 60)
    cycle_time_seconds = int(cycle_time_seconds % 60)

    # Output results
    print(f"Steps per epoch: {steps_per_epoch}")
    print(f"Number of training cycles: {training_cycles}")
    print(f"Cycle time: {cycle_time_hours} hours, {cycle_time_minutes} minutes, {cycle_time_seconds} seconds")

input("Press Enter to exit...")