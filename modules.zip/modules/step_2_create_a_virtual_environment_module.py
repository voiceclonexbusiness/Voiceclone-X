#2. Create a Virtual Environment

import os
import subprocess
import sys
import shutil
import time

# ANSI escape code for light blue text
LIGHT_BLUE = "\033[94m"
RESET = "\033[0m"

def main():
    proceed = input(LIGHT_BLUE + "Do you want to Create a Virtual Environment? (Y/N): " + RESET).strip().lower()
    if proceed != 'y':
        print("Operation cancelled.")
        return

    base_dir = r"C:\Voiceclone X\environments"
    os.makedirs(base_dir, exist_ok=True)

    env_name = input("Enter the name for the virtual environment: ")
    env_path = create_virtual_environment(base_dir, env_name)

    install_packages_prompt = input("Would you like to install the requirements for voice cloning? (Y/N): ").strip().lower()
    if install_packages_prompt == 'y':
        packages = [
            "fairseq==0.12.2",
            "faiss-cpu==1.7.4",
            "numpy==1.23.5",
            "scikit-learn==1.3.0",
            "torch==2.0.0",
            "torchvision==0.15.0",
            "torchaudio==0.12.1",
            "librosa==0.10.0.post2",
            "tensorflow==2.13.0",
            "av==10.0.0",
            "pandas==2.0.3",
            "requests==2.31.0",
            "praat-parselmouth==0.4.3",
            "tqdm==4.65.0",
            "pyworld==0.3.2",
            "mkl-static==2024.2.0",
            "mkl-include==2024.2.0",
            "matplotlib>=3.9.1",
            "matplotlib-inline==0.1.7",
            "pillow==9.5.0"
        ]
        install_packages(env_path, packages)

    print(f"\nVirtual environment created at: {env_path}")

def create_virtual_environment(base_dir, env_name):
    """Create a virtual environment with the specified name."""
    env_path = os.path.join(base_dir, env_name)
    print(f"Creating virtual environment at: {env_path}")
    subprocess.run([sys.executable, "-m", "venv", env_path], check=True)
    return env_path

def install_packages(env_path, packages):
    """Install specified packages into the virtual environment."""
    pip_executable = os.path.join(env_path, 'Scripts', 'pip.exe') if os.name == 'nt' else os.path.join(env_path, 'bin', 'pip')

    total_packages = len(packages)
    if total_packages == 0:
        print("No packages specified.")
        return

    print(f"Total packages to install: {total_packages}")

    for i, package in enumerate(packages):
        print(f"\nInstalling package {i + 1}/{total_packages}: {package}")
        display_loading_bar(0, 100)  # Start the loading bar at 0%

        result = subprocess.run([pip_executable, 'install', package], capture_output=True, text=True)
        if result.returncode == 0:
            print(f"Successfully installed {package}.")
        else:
            print(f"Failed to install {package}. Error: {result.stderr}")

        display_loading_bar(100, 100)  # Complete the loading bar

    print("All specified packages have been installed.")
    pip_cache_purge(pip_executable)

def display_loading_bar(progress, total):
    """Display a simple loading bar."""
    bar_length = 40
    completed = int(bar_length * progress / total)
    bar = '#' * completed + '-' * (bar_length - completed)
    print(f"[{bar}] {progress}/{total}%")
    time.sleep(0.1)  # Simulate progress

def pip_cache_purge(pip_executable):
    """Purge the pip cache."""
    result = subprocess.run([pip_executable, 'cache', 'purge'], capture_output=True, text=True)
    if result.returncode == 0:
        print("Pip cache purged successfully.")
    else:
        print(f"Failed to purge pip cache. Error: {result.stderr}")
    
    delete_user_cache()

def delete_user_cache():
    """Delete the user cache folder for pip."""
    user_home = os.path.expanduser('~')
    local_cache_dir = os.path.join(user_home, 'AppData', 'Local', 'Packages')
    if not os.path.exists(local_cache_dir):
        print("Local cache directory does not exist.")
        return

    for root, dirs, files in os.walk(local_cache_dir):
        for dir_name in dirs:
            if "PythonSoftwareFoundation.Python" in dir_name:
                pip_cache_dir = os.path.join(root, dir_name, 'LocalCache', 'Local', 'pip', 'cache')
                if os.path.exists(pip_cache_dir):
                    print(f"Deleting pip cache directory: {pip_cache_dir}")
                    try:
                        shutil.rmtree(pip_cache_dir)
                        print("Pip cache directory deleted successfully.")
                    except Exception as e:
                        print(f"Failed to delete pip cache directory. Error: {e}")
                return

    print("Pip cache directory not found.")

if __name__ == "__main__":
    main()