#1. Change Command Prompt Execution Policy

import subprocess

# ANSI escape code for light blue text
LIGHT_BLUE = "\033[94m"
RESET = "\033[0m"

def get_execution_policy():
    """Get the current execution policy from PowerShell."""
    try:
        result = subprocess.run(
            ["powershell", "-Command", "Get-ExecutionPolicy"],
            capture_output=True, text=True, check=True
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        print(f"Error getting execution policy: {e}")
        return None

def set_execution_policy(policy):
    """Set the execution policy to the specified policy."""
    try:
        subprocess.run(
            ["powershell", "-Command", f"Set-ExecutionPolicy {policy} -Scope CurrentUser -Force"],
            check=True
        )
        print(f"Execution policy set to {policy}.")
    except subprocess.CalledProcessError as e:
        print(f"Error setting execution policy: {e}")

def main():
    # Ask user if they want to continue with the script
    proceed = input(LIGHT_BLUE + "Do you want to change Command Prompt Execution Policy? (Y/N): " + RESET).strip().lower()
    if proceed != 'y':
        print("Operation cancelled.")
        return

    current_policy = get_execution_policy()
    if current_policy is None:
        print("Failed to retrieve the current execution policy.")
        return

    print(f"Current Execution Policy: {current_policy}")

    if current_policy == "RemoteSigned":
        reset_input = input(LIGHT_BLUE + "The current policy is 'RemoteSigned'. Do you want to reset the execution policy to the default 'Restricted'? (Y/N): " + RESET).strip().lower()
        if reset_input == 'y':
            default_policy = "Restricted"
            print(f"Resetting execution policy to {default_policy}...")
            set_execution_policy(default_policy)
            
            # Ask if the user wants to set it back to RemoteSigned
            reset_back_input = input(LIGHT_BLUE + "Do you want to change the execution policy back to 'RemoteSigned'? (Y/N): " + RESET).strip().lower()
            if reset_back_input == 'y':
                print("Changing execution policy back to RemoteSigned...")
                set_execution_policy("RemoteSigned")
            elif reset_back_input == 'n':
                print("Keeping the current execution policy as 'Restricted'.")
            else:
                print("Invalid input. Please enter 'Y' for yes or 'N' for no.")
        elif reset_input == 'n':
            print("Keeping the current execution policy as 'RemoteSigned'.")
        else:
            print("Invalid input. Please enter 'Y' for yes or 'N' for no.")
    else:
        user_input = input(LIGHT_BLUE + "Do you want to change the execution policy to 'RemoteSigned'? (Y/N): " + RESET).strip().lower()
        if user_input == 'y':
            print("Changing execution policy to RemoteSigned...")
            set_execution_policy("RemoteSigned")
        elif user_input == 'n':
            print("Operation cancelled.")
        else:
            print("Invalid input. Please enter 'Y' for yes or 'N' for no.")

if __name__ == "__main__":
    main()