import os
import pathlib
import json
import zipfile
from random import shuffle
from subprocess import Popen, PIPE, STDOUT
from nicegui import ui

# Function to save the model as a zip file
def save_model_as_zip(model_name):
    # Define main paths
    main_path = r"C:\RVC\content\project-main"
    saved_models_path = r"C:\RVC\content\saved_models"

    # Define file paths
    index_file_dir = os.path.join(main_path, "logs", model_name)
    index_file_source = None
    for filename in os.listdir(index_file_dir):
        if filename.endswith(".index") and f"_{model_name}_v2" in filename:
            index_file_source = os.path.join(index_file_dir, filename)
            break

    if index_file_source is None:
        print(f"Error: Index file for model '{model_name}' not found.")
        return

    weights_file_source = os.path.join(main_path, "assets", "weights", f"{model_name}.pth")
    zip_file_path = os.path.join(saved_models_path, f"{model_name}.zip")

    # Check if weights file exists
    if not os.path.isfile(weights_file_source):
        print(f"Error: Weights file '{weights_file_source}' not found.")
        return

    # Create zip file for the model
    with zipfile.ZipFile(zip_file_path, 'w') as zipf:
        zipf.write(index_file_source, os.path.basename(index_file_source))
        zipf.write(weights_file_source, os.path.basename(weights_file_source))

    print(f"Model '{model_name}' saved successfully as '{model_name}.zip'.")

# Function to list available models
def list_available_models():
    logs_path = r"C:\RVC\content\project-main\logs"
    models = [d for d in os.listdir(logs_path) if os.path.isdir(os.path.join(logs_path, d)) and d != 'mute']
    return models

# Function to select model
def select_model():
    models = list_available_models()
    if not models:
        return []

    return models

def train_model(model_name, save_frequency, epochs, batch_size, gpu_count):
    # Define paths and other parameters
    now_dir = r"C:\RVC\content\project-main"
    os.chdir(now_dir)

    pretrained_G = 'assets/pretrained_v2/f0G40k.pth'
    pretrained_D = 'assets/pretrained_v2/f0D40k.pth'

    # Define function to train model
    def click_train(exp_dir1):
        exp_dir = os.path.join(now_dir, rf'logs\{exp_dir1}')
        os.makedirs(exp_dir, exist_ok=True)

        # Generate filelist (mocked for the example)
        gt_wavs_dir = os.path.join(exp_dir, '0_gt_wavs')
        feature_dir = os.path.join(exp_dir, '3_feature768')
        names = {name.split(".")[0] for name in os.listdir(gt_wavs_dir)}
        opt = [f"{gt_wavs_dir}\\{name}.wav|{feature_dir}\\{name}.npy|0" for name in names]
        
        with open(f"{exp_dir}\\filelist.txt", "w") as f:
            f.write("\n".join(opt))

        cmd = (
            rf'python "C:\RVC\content\project-main\infer\modules\train\train.py" '
            rf'-se {save_frequency} '
            rf'-te {epochs} '
            rf'-pg {pretrained_G} '
            rf'-pd {pretrained_D} '
            rf'-g {gpu_count} '
            rf'-bs {batch_size} '
            rf'-e "{exp_dir1}" '
        )

        p = Popen(cmd, shell=True, cwd=now_dir, stdout=PIPE, stderr=STDOUT, bufsize=1, universal_newlines=True)
        for line in p.stdout:
            print(line.strip())
        p.wait()
        return exp_dir1

    try:
        trained_model_name = click_train(model_name)
        print("Training completed successfully.")
        save_model_as_zip(trained_model_name)

    except Exception as e:
        print("An error occurred during training:", e)

# NiceGUI Interface
with ui.card().style('width: 400px;'):
    ui.label('Train Model')
    
    model_dropdown = ui.select(label="Select Model", options=select_model())  # Use keyword argument for options
    save_frequency_input = ui.input("Save Frequency (1-50)", type='number', min=1, max=50)
    epochs_input = ui.input("Epochs (1-10000)", type='number', min=1, max=10000)
    batch_size_input = ui.input("Batch Size (7-32)", type='number', min=7, max=32)
    gpu_count_input = ui.input("GPU Count (0-16)", type='number', min=0, max=16)

    ui.button("Train Model", on_click=lambda: train_model(
        model_dropdown.value,
        save_frequency_input.value,
        epochs_input.value,
        batch_size_input.value,
        gpu_count_input.value,
    ))

ui.run()
