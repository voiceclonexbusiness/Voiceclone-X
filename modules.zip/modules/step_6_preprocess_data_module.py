#6. Preprocess Data

import os

# Ask the user if they want to preprocess their data and continue
user_input = input("Preprocess Data? (Y/N): ").strip().lower()

if user_input != 'y':
    print("Operation cancelled.")
else:
    # Data Preparation
    os.chdir(r'C:\RVC\content\project-main')
    dataset_folder = r'C:\RVC\content\dataset'  # Dataset folder path

    # Get the list of models (subdirectories) in the dataset folder
    models = [d for d in os.listdir(dataset_folder) if os.path.isdir(os.path.join(dataset_folder, d))]

    if not models:
        print("No models found in the dataset folder.")
    else:
        # Display dropdown menu for model selection
        print("Select a dataset from the list below:")
        for i, model in enumerate(models, start=1):
            print(f"{i}. {model}")
        
        model_choice = int(input("Enter the number corresponding to your model: "))
        model_name = models[model_choice - 1]  # Get the selected model name

        # Path to the specific model's dataset folder
        model_dataset_folder = os.path.join(dataset_folder, model_name)

        while len(os.listdir(model_dataset_folder)) < 1:
            input("Your dataset folder is empty. Please make sure it contains the necessary audio files.")

        # Create logs directory
        os.makedirs(os.path.join('.', 'logs', model_name), exist_ok=True)

        # Preprocessing
        preprocess_log_path = os.path.join('.', 'logs', model_name, 'preprocess.log')
        with open(preprocess_log_path, 'w') as f:
            print("Starting...")

        # Execute preprocessing script
        os.system(f'python infer/modules/train/preprocess.py {model_dataset_folder} 40000 2 ./logs/{model_name} False 3.0 > nul 2>&1')

        # Check if preprocessing was successful
        with open(preprocess_log_path, 'r') as f:
            if 'end preprocess' in f.read():
                print("\u2714 Success")
            else:
                print("Error preprocessing data. Please ensure your dataset folder is correct.")