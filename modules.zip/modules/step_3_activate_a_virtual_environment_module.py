#3. Activate Virtual Environment

import os
import subprocess
import sys

# ANSI escape codes for colors
LIGHT_BLUE = "\033[94m"
LIGHT_GREEN = "\033[92m"
RESET = "\033[0m"

# Path to the environments directory
ENVIRONMENTS_DIR = r"C:\Voiceclone X\environments"

# Function to list available virtual environments
def list_virtual_environments(environments_dir):
    try:
        environments = [d for d in os.listdir(environments_dir) if os.path.isdir(os.path.join(environments_dir, d))]
        if not environments:
            print("No virtual environments found in the specified directory.")
            sys.exit(1)
        return environments
    except FileNotFoundError:
        print(f"The directory {environments_dir} does not exist.")
        sys.exit(1)

# Prompt user to select a virtual environment
def select_virtual_environment(environments):
    print("Available virtual environments:")
    for idx, env in enumerate(environments, start=1):
        print(f"{idx}. {env}")
    
    choice = input("Enter the number of the virtual environment you want to use: ").strip()
    
    try:
        choice_idx = int(choice) - 1
        if 0 <= choice_idx < len(environments):
            return environments[choice_idx]
        else:
            print("Invalid choice. Please enter a valid number.")
            sys.exit(1)
    except ValueError:
        print("Invalid input. Please enter a number.")
        sys.exit(1)

# Prompt user to continue
def prompt_to_continue():
    response = input(LIGHT_BLUE + "Do you want to activate a virtual environment? (Y/N): " + RESET).strip().lower()
    if response != 'y':
        print("Operation cancelled.")
        sys.exit(0)

def main():
    # Prompt user to continue
    prompt_to_continue()
    
    # List and select virtual environment
    environments = list_virtual_environments(ENVIRONMENTS_DIR)
    selected_env = select_virtual_environment(environments)

    VIRTUAL_ENVIRONMENT_DIR = os.path.join(ENVIRONMENTS_DIR, selected_env)
    activate_script = os.path.join(VIRTUAL_ENVIRONMENT_DIR, "Scripts", "activate.bat")

    # Path to the script to run
    script_to_run = r"C:\Voiceclone X\apps\voiceclonex APP.py"

    # Display selected environment
    print(f"Selected virtual environment: " + LIGHT_GREEN + f"{selected_env}" + RESET)

    # Use subprocess to execute the activation script
    try:
        # Properly quote the paths
        activate_command = f'"{activate_script}"'
        
        # Combined command to activate the environment and run the script
        run_script_command = f'cmd /k "{activate_command} && python "{script_to_run}""'
        
        subprocess.run(run_script_command, shell=True, check=True)
        print(f"Successfully activated the virtual environment '{selected_env}' and ran the script.")
        
    except subprocess.CalledProcessError:
        print(f"Failed to activate the virtual environment '{selected_env}' or run the script.")
        sys.exit(1)

if __name__ == "__main__":
    main()